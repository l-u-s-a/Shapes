package hr.fer.oop.lab1.topic2.prob1;

import hr.fer.oop.lab1.topic2.pic.Picture;

/**
 * @author Luka Ušalj
 * @version = 1.0
 */

public class Line {

    int x;
    int y;

    public Line(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public Line(Line line) {
        this(line.x, line.y);
    }


    public static void drawOnPicture(Picture picture){
        // Draw horizontal line on y=10:
        for(int i = 0, n = picture.getWidth(); i < n; i++) {
            picture.turnPixelOn(i, 5);

            // Render picture is ASCII-graphics on standard output:
            picture.renderImageToStream(System.out);
        }
    }
}
