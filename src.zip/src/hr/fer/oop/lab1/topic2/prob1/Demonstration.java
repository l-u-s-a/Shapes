package hr.fer.oop.lab1.topic2.prob1;
import hr.fer.oop.lab1.topic2.pic.*;


/**
 * Created by luka on 20/10/14.
 */
public class Demonstration {

    public static void main(String[] args){

        Picture picture = new Picture(100, 50);

        Rectangle rect1 = new Rectangle(10, 10, 10, 10);
        Rectangle rect2 = new Rectangle(30, -19, 15, 15);
        Line line1 = new Line(10, 10);
        Line line2 = new Line (-10, -30);
        Circle circle1 = new Circle(40, 10, 10);
        Circle circle2 = new Circle(40, 0, 10);
                

        Line.drawOnPicture(picture);

    }
}
