package hr.fer.oop.lab1.topic2.prob1;

/**
 * Created by luka on 20/10/14.
 */
public class Point {
    public int x, y;
    public Point(int x, int y){
        this.x = x;
        this.y = y;
    }
    public Point(Point point){
        this(point.x, point.y);
    }
}
