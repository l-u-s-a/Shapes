package hr.fer.oop.lab1.topic2.prob1;

/**
 * Created by luka on 20/10/14.
 */
public class Main {
    public static void main(String[] args){

    }
}
