package hr.fer.oop.lab1.topic2.prob1;
import hr.fer.oop.lab1.topic2.pic.*;


/**
 * Created by luka on 20/10/14.
 */
public class Circle {

    int r;
    int x;
    int y;


    public Circle(int r, int x, int y){
        this.r = r;
        this.x = x;
        this.y = y;
    }

    public static void drawOnPicture(Picture picture){
        // Draw horizontal line on y=10:
        for(int i = 0, n = picture.getWidth(); i < n; i++) {
            picture.turnPixelOn(i, 10);

            // Render picture is ASCII-graphics on standard output:
            picture.renderImageToStream(System.out);
        }
    }
}
