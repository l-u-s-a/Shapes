package hr.fer.oop.lab1.topic2.prob1;

import hr.fer.oop.lab1.topic2.pic.Picture;
import hr.fer.oop.lab1.topic2.pic.PictureDisplay;

/**
 * Created by luka on 20/10/14.
 */
public class Rectangle {

    private int topX;
    private int topY;
    private int width;
    private int height;


    public Rectangle(int x, int y, int width, int height){
        this.topX = x;
        this.topY = y;
        this.width = width;
        this.height = height;
    }



    public Rectangle(Rectangle rectangle) {
        this(rectangle.topX, rectangle.topY, rectangle.width, rectangle.height);
    }

    public static void drawOnPicture(Picture picture){
        // Draw horizontal line on y=10:
        for(int i = 0, n = picture.getWidth(); i < n; i++) {
            picture.turnPixelOn(i, 10);

            // Render picture is ASCII-graphics on standard output:
            picture.renderImageToStream(System.out);
        }
    }


}
